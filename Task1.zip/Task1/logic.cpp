#include "logic.h"
#include <cctype>

using namespace std;

// Вспомогательная функция для проверки границ склада
bool isValidAddress(const string& address, string& error_msg) {
    size_t num_start = 0;
    
    // принимаем только кириллические буквы А и Б
    if (address.find("А") == 0 || address.find("Б") == 0) {
        num_start = 2;
    } else {
        error_msg = "Неверная зона хранения (разрешены только КИРИЛЛИЧЕСКИЕ буквы А и Б)";
        return false;
    }

    // Вырезаем цифровую часть адреса
    string numbers = address.substr(num_start);
    
    // Длина цифровой части должна быть от 3 до 4 символа
    if (numbers.length() < 3 || numbers.length() > 4) {
        error_msg = "Неверный формат числовых индексов";
        return false;
    }

    // символы в числовой части — это цифры
    for (char c : numbers) {
        if (!isdigit(c)) {
            error_msg = "Адрес содержит некорректные символы";
            return false;
        }
    }

    // Так как секция и полка всегда однозначные, забираем их с конца строки
    int shelf = numbers.back() - '0';
    numbers.pop_back();

    int section = numbers.back() - '0';
    numbers.pop_back();

    // Всё, что осталось в строке — это номер стеллажа
    int rack = stoi(numbers);

    // Проверка жестких границ
    if (rack < 1 || rack > 13) {
        error_msg = "Номер стеллажа выходит за границы диапазона (доступно: 1-13)";
        return false;
    }
    if (section < 1 || section > 7) {
        error_msg = "Номер секции выходит за границы диапазона (доступно: 1-7)";
        return false;
    }
    if (shelf < 1 || shelf > 9) {
        error_msg = "Номер полки выходит за границы диапазона (доступно: 1-9)";
        return false;
    }

    return true;
}

void addProduct(map<string, Cell>& warehouse, const string& name, int count, const string& address) {
    if (count <= 0) {
        cout << "Ошибка: Количество добавляемого товара должно быть больше 0\n";
        return;
    }

    string error_msg;
    if (!isValidAddress(address, error_msg)) {
        cout << "Ошибка: " << error_msg << " в адресе " << address << "\n";
        return;
    }

    if (warehouse.count(address) > 0 && warehouse.at(address).product_name != name) {
        cout << "Ошибка: Ячейка " << address << " занята товаром " << warehouse.at(address).product_name << "\n";
        return;
    }

    int current_count = (warehouse.count(address) > 0) ? warehouse.at(address).count : 0;
    if (current_count + count > 10) {
        cout << "Ошибка: Превышена вместимость ячейки (максимум 10)\n";
        return;
    }

    warehouse[address].product_name = name;
    warehouse[address].count += count;
    cout << "Добавлено " << count << " " << name << " в " << address << "\n";
}

void removeProduct(map<string, Cell>& warehouse, const string& name, int count, const string& address) {
    if (count <= 0) {
        cout << "Ошибка: Количество удаляемого товара должно быть больше 0\n";
        return;
    }

    string error_msg;
    if (!isValidAddress(address, error_msg)) {
        cout << "Ошибка: " << error_msg << " в адресе " << address << "\n";
        return;
    }

    if (warehouse.count(address) == 0 || warehouse.at(address).product_name != name) {
        cout << "Ошибка: Товар " << name << " не найден в ячейке " << address << "\n";
        return;
    }

    if (warehouse.at(address).count < count) {
        cout << "Ошибка: Недостаточно товаров для удаления\n";
        return;
    }

    warehouse[address].count -= count;
    cout << "Удалено " << count << " " << name << " (остаток: " << warehouse[address].count << ")\n";

    if (warehouse[address].count == 0) {
        warehouse.erase(address);
    }
}

void printInfo(const map<string, Cell>& warehouse) {
    double total_capacity = 16380.0; // Общая вместимость
    double zone_capacity = 8190.0;
    int zone_A_count = 0;
    int zone_B_count = 0;

    // Считаем заполненные ячейки строго по кириллическим зонам
    for (const auto& item : warehouse) {
        if (item.first.find("А") == 0) {
            zone_A_count++;
        } else if (item.first.find("Б") == 0) {
            zone_B_count++;
        }
    }

    cout << fixed << setprecision(2);
    cout << "Загруженность склада: " << (warehouse.size() / total_capacity) * 100.0 << "%\n";
    cout << "Загруженность зоны А: " << (zone_A_count / zone_capacity) * 100.0 << "%\n";
    cout << "Загруженность зоны Б: " << (zone_B_count / zone_capacity) * 100.0 << "%\n";

    cout << "Заполненные ячейки:\n";
    for (const auto& item : warehouse) {
        cout << item.first << ": " << item.second.product_name << " (" << item.second.count << ")\n";
    }

    cout << "Пустые ячейки:\n";
    
    vector<string> zones = {"А", "Б"};
    vector<int> racks = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13}; // 13 стеллажей 
    vector<int> sections = {1, 2, 3, 4, 5, 6, 7};                 // 7 секций
    vector<int> shelves = {1, 2, 3, 4, 5, 6, 7, 8, 9};               // 9 полок

    bool first = true;
    int items_in_line = 0; 
    
    // Все циклы строго Range-based
    for (const auto& z : zones) {
        for (const auto& r : racks) {
            for (const auto& s : sections) {
                for (const auto& sh : shelves) {
                    string addr = z + to_string(r) + to_string(s) + to_string(sh);
                    if (warehouse.count(addr) == 0) {
                        if (!first) {
                            cout << ", ";
                        }
                        cout << addr;
                        first = false;
                        items_in_line++;
                        
                        // Постраничный перенос
                        if (items_in_line >= 15) {
                            cout << "\n";
                            first = true; 
                            items_in_line = 0;
                        }
                    }
                }
            }
        }
    }
    cout << "\n";
}
