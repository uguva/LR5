#include "logic.h"
#include <algorithm>

using namespace std;

int main() {
    map<string, Cell> warehouse;
    string command;

    // Цикл обработки команд из консоли 
    while (cin >> command) {
        // Приводим команду к верхнему регистру
        transform(command.begin(), command.end(), command.begin(), ::toupper);

        if (command == "ADD" || command == "REMOVE") {
            string name, address;
            int count;

            cin >> name;
            
            // Защита от ввода текста вместо числа
            if (!(cin >> count)) {
                cout << "Ошибка: Количество товара должно быть целым числом!\n";
                cin.clear(); 
                string garbage;
                cin >> garbage; 
                continue;
            }

            cin >> address;

            if (command == "ADD") {
                addProduct(warehouse, name, count, address);
            } else {
                removeProduct(warehouse, name, count, address);
            }
        } 
        else if (command == "INFO") {
            printInfo(warehouse);
        }
        else if (command == "EXIT") {
            break;
        }
        else {
            cout << "Ошибка: Неизвестная команда '" << command << "'\n";
        }
    }

    return 0;
}
