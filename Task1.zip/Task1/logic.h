#pragma once

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <iomanip>

// Структура для хранения информации о товаре в ячейке
struct Cell {
    std::string product_name;
    int count = 0;
};

// Объявления функций, вынесенные из основного файла
void addProduct(std::map<std::string, Cell>& warehouse, const std::string& name, int count, const std::string& address);
void removeProduct(std::map<std::string, Cell>& warehouse, const std::string& name, int count, const std::string& address);
void printInfo(const std::map<std::string, Cell>& warehouse);
