#pragma once

#include <iostream>
#include <string>
#include <vector>

// Структура контейнера
struct Container {
    std::string id;
    int weight = 0;
    int arrival_order = 0; // Порядковый номер прибытия (для реализации LIFO)
};

// Структура стека в порту
struct Stack {
    int current_weight = 0;
    std::vector<Container> items;
};

// Структура секции судна
struct Section {
    int current_weight = 0;
    std::vector<std::string> loaded_ids;
};

// Объявления функций (аргумент id передается по значению для автоконвертации)
void arriveContainer(std::vector<Stack>& port, int max_stack_weight, std::string id, int weight, int& arrival_counter);
void loadShip(std::vector<Stack>& port, std::vector<Section>& ship);
