#include "logic.h"
#include <cctype>

using namespace std;

// Вспомогательная функция для проверки формата и автоконвертации в латиницу
bool isValidAndNormalizeContainerId(string& id, string& error_msg) {
    // 1. Проверяем, не введена ли кириллическая заглавная 'С' (в UTF-8 это 2 байта)
    if (id.find("С") == 0) {
        // Заменяем первые 2 байта кириллической 'С' на 1 байт латинской 'C'
        id = "C" + id.substr(2);
    }
    // 2. Проверяем, введена ли латинская заглавная 'C'
    else if (id.find("C") != 0) {
        error_msg = "Идентификатор должен начинаться с заглавной буквы 'C' (например, C001)";
        return false;
    }

    // Извлекаем числовую часть
    string numbers = id.substr(1);
    
    // Длина должна быть ровно 3 цифры
    if (numbers.length() != 3) {
        error_msg = "После буквы 'C' должно идти ровно 3 цифры (например, C001, C012)";
        return false;
    }

    // Проверяем, что нет скрытого мусора (букв вместо цифр)
    for (char c : numbers) {
        if (!isdigit(c)) {
            error_msg = "После буквы 'C' должны идти только цифры";
            return false;
        }
    }
    return true;
}

// Вспомогательная функция проверки на дубликаты в порту
bool isContainerInPort(const vector<Stack>& port, const string& id) {
    for (const auto& s : port) {
        for (const auto& c : s.items) {
            if (c.id == id) {
                return true;
            }
        }
    }
    return false;
}

void arriveContainer(vector<Stack>& port, int max_stack_weight, string id, int weight, int& arrival_counter) {
    string error_msg;
    
    if (!isValidAndNormalizeContainerId(id, error_msg)) {
        cout << "Ошибка: " << error_msg << "\n";
        return;
    }

    if (isContainerInPort(port, id)) {
        cout << "Ошибка: Контейнер " << id << " уже находится в порту!\n";
        return;
    }

    if (weight <= 0) {
        cout << "Ошибка: Вес контейнера должен быть больше 0\n";
        return;
    }
    if (weight > max_stack_weight) {
        cout << "Ошибка: Вес контейнера (" << weight << "т) превышает вместимость стека (" << max_stack_weight << "т)\n";
        return;
    }

    arrival_counter++;
    Container c = {id, weight, arrival_counter};

    int stack_idx = 1;
    bool placed = false;

    for (auto& s : port) {
        if (s.current_weight + weight <= max_stack_weight) {
            s.items.push_back(c);
            s.current_weight += weight;
            cout << "Контейнер " << id << " размещен в стек " << stack_idx << "\n";
            placed = true;
            break;
        }
        stack_idx++;
    }

    if (!placed) {
        Stack new_stack;
        new_stack.items.push_back(c);
        new_stack.current_weight += weight;
        port.push_back(new_stack);
        cout << "Контейнер " << id << " размещен в стек " << port.size() << "\n";
    }
}

void loadShip(vector<Stack>& port, vector<Section>& ship) {
    bool has_containers = false;
    for (const auto& s : port) {
        if (!s.items.empty()) {
            has_containers = true;
            break;
        }
    }

    if (!has_containers) {
        cout << "Ошибка: Порт пуст, нет контейнеров для погрузки на судно.\n";
        return;
    }

    while (true) {
        Stack* best_stack = nullptr;
        int latest_arrival = -1;

        for (auto& s : port) {
            if (!s.items.empty()) {
                if (s.items.back().arrival_order > latest_arrival) {
                    latest_arrival = s.items.back().arrival_order;
                    best_stack = &s;
                }
            }
        }

        if (best_stack == nullptr) {
            break; 
        }

        Container to_load = best_stack->items.back();
        best_stack->items.pop_back();
        best_stack->current_weight -= to_load.weight;

        Section* best_section = nullptr;
        int min_weight = 2147483647;

        for (auto& sec : ship) {
            if (sec.current_weight < min_weight) {
                min_weight = sec.current_weight;
                best_section = &sec;
            }
        }

        best_section->loaded_ids.push_back(to_load.id);
        best_section->current_weight += to_load.weight;
    }

    port.clear();

    int sec_idx = 1;
    for (const auto& sec : ship) {
        cout << "Секция " << sec_idx << " (" << sec.current_weight << " тонн): ";
        if (sec.loaded_ids.empty()) {
            cout << "пусто";
        } else {
            bool first = true;
            for (const auto& id : sec.loaded_ids) {
                if (!first) cout << ", ";
                cout << id;
                first = false;
            }
        }
        cout << "\n";
        sec_idx++;
    }
}
