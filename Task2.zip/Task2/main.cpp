#include "logic.h"
#include <algorithm>
#include <limits>

using namespace std;

void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int main() {
    int max_stack_weight = 0;
    int num_sections = 0;

    cout << "Введите максимальный размер стека:\n>>> ";
    while (!(cin >> max_stack_weight) || max_stack_weight <= 0) {
        cout << "Ошибка: Размер стека должен быть положительным числом.\n>>> ";
        clearInput();
    }

    cout << "Введите количество секций судна:\n>>> ";
    while (!(cin >> num_sections) || num_sections <= 0) {
        cout << "Ошибка: Количество секций должно быть положительным числом.\n>>> ";
        clearInput();
    }

    vector<Stack> port;
    vector<Section> ship(num_sections);
    int arrival_counter = 0;
    string command;

    cout << "Система готова. Команды: ARRIVE <id> <вес>, LOAD, EXIT\n";

    while (cin >> command) {
        transform(command.begin(), command.end(), command.begin(), ::toupper);

        if (command == "ARRIVE") {
            string id;
            int weight;
            
            cin >> id;
            
            if (!(cin >> weight)) {
                cout << "Ошибка: Вес контейнера должен быть целым числом!\n";
                clearInput();
                continue;
            }

            arriveContainer(port, max_stack_weight, id, weight, arrival_counter);
        }
        else if (command == "LOAD") {
            loadShip(port, ship);
        }
        else if (command == "EXIT") {
            break;
        }
        else {
            cout << "Ошибка: Неизвестная команда '" << command << "'\n";
            clearInput();
        }
    }

    return 0;
}
