#include "logic.h"
#include <algorithm>
#include <limits>

using namespace std;

// Безопасная очистка буфера
void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

int main() {
    int total_requests = 0;
    cout << "Введите количество запросов (N):\n>>> ";
    
    // Защита от ввода некорректного N
    while (!(cin >> total_requests) || total_requests <= 0) {
        cout << "Ошибка: Количество запросов должно быть положительным числом.\n>>> ";
        clearInput();
    }

    map<string, Book> books;
    map<string, set<string>> readers;
    string command;

    cout << "Система готова к обработке " << total_requests << " запросов.\n";

    // Выполняем ровно N запросов, как требует задание 4
    for (int i = 0; i < total_requests; ++i) {
        cout << ">>> ";
        if (!(cin >> command)) break;

        // Приведение к верхнему регистру для поддержки любого ввода (add_book, ADD_BOOK)
        transform(command.begin(), command.end(), command.begin(), ::toupper);

        if (command == "ADD_BOOK") {
            string book_id, name;
            cin >> book_id >> name;
            addBook(books, book_id, name);
        }
        else if (command == "BORROW") {
            string book_id, reader_id;
            cin >> book_id >> reader_id;
            borrowBook(books, readers, book_id, reader_id);
        }
        else if (command == "RETURN") {
            string book_id;
            cin >> book_id;
            returnBook(books, readers, book_id);
        }
        else if (command == "BOOK_STATUS") {
            string book_id;
            cin >> book_id;
            bookStatus(books, book_id);
        }
        else if (command == "READER_BOOKS") {
            string reader_id;
            cin >> reader_id;
            readerBooks(readers, reader_id);
        }
        else {
            cout << "Ошибка: Неизвестная библиотека кодов '" << command << "'\n";
            clearInput();
        }
    }

    cout << "Программа завершила обработку лимита запросов.\n";
    return 0;
}
