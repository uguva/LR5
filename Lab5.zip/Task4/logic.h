#pragma once

#include <iostream>
#include <string>
#include <map>
#include <set>

// Структура для хранения информации о книге
struct Book {
    std::string id;
    std::string name;
    std::string location = "LIBRARY"; // Может быть "LIBRARY" или ID читателя (например, "R001")
};

// Объявления функций логики библиотеки
void addBook(std::map<std::string, Book>& books, const std::string& book_id, const std::string& name);
void borrowBook(std::map<std::string, Book>& books, std::map<std::string, std::set<std::string>>& readers, const std::string& book_id, const std::string& reader_id);
void returnBook(std::map<std::string, Book>& books, std::map<std::string, std::set<std::string>>& readers, const std::string& book_id);
void bookStatus(const std::map<std::string, Book>& books, const std::string& book_id);
void readerBooks(const std::map<std::string, std::set<std::string>>& readers, const std::string& reader_id);
