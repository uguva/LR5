#include "logic.h"

using namespace std;

void addBook(map<string, Book>& books, const string& book_id, const string& name) {
    // Проверка: Книга с таким ID уже существует
    if (books.count(book_id) > 0) {
        cout << "Ошибка: Книга с идентификатором " << book_id << " уже существует\n";
        return;
    }

    // Добавляем новую книгу в базу
    Book new_book = {book_id, name, "LIBRARY"};
    books[book_id] = new_book;
    cout << "Книга " << book_id << " " << name << " добавлена\n";
}

void borrowBook(map<string, Book>& books, map<string, set<string>>& readers, const string& book_id, const string& reader_id) {
    // Проверка 1: Существует ли книга вообще
    if (books.count(book_id) == 0) {
        cout << "Ошибка: Книги с идентификатором " << book_id << " не существует\n";
        return;
    }

    // Проверка 2: Не находится ли книга уже у кого-то на руках
    if (books.at(book_id).location != "LIBRARY") {
        cout << "Ошибка: Книга " << book_id << " уже выдана читателю " << books.at(book_id).location << "\n";
        return;
    }

    // Проверка 3: Не превысил ли читатель лимит в 2 книги
    if (readers.count(reader_id) > 0 && readers.at(reader_id).size() >= 2) {
        cout << "Ошибка: Книгу нельзя выдать читателю " << reader_id << ", поскольку у него превышен лимит\n";
        return;
    }

    // Выдаем книгу читателю
    books[book_id].location = reader_id;
    readers[reader_id].insert(book_id);
    cout << "Книга " << book_id << " выдана читателю " << reader_id << "\n";
}

void returnBook(map<string, Book>& books, map<string, set<string>>& readers, const string& book_id) {
    // Проверка 1: Существует ли книга
    if (books.count(book_id) == 0) {
        cout << "Ошибка: Книги с идентификатором " << book_id << " не существует\n";
        return;
    }

    // Проверка 2: Находится ли книга в библиотеке (ее нельзя вернуть, если она уже там)
    if (books.at(book_id).location == "LIBRARY") {
        cout << "Ошибка: Книга " << book_id << " уже находится в библиотеке\n";
        return;
    }

    // Запоминаем, у какого читателя она была
    string reader_id = books.at(book_id).location;

    // Меням статус локации книги
    books[book_id].location = "LIBRARY";

    // Удаляем книгу из списка книг на руках у этого читателя
    readers[reader_id].erase(book_id);
    
    // Если у читателя не осталось книг, можно удалить его из мапы для экономии памяти
    if (readers[reader_id].empty()) {
        readers.erase(reader_id);
    }

    cout << "Книга " << book_id << " возвращена в библиотеку\n";
}

void bookStatus(const map<string, Book>& books, const string& book_id) {
    // Проверка: Существует ли книга
    if (books.count(book_id) == 0) {
        cout << "Ошибка: Книги с идентификатором " << book_id << " не существует\n";
        return;
    }

    const Book& b = books.at(book_id);
    if (b.location == "LIBRARY") {
        cout << "Книга " << b.id << " находится в библиотеке\n";
    } else {
        cout << "Книга " << b.id << " находится у читателя " << b.location << "\n";
    }
}

void readerBooks(const map<string, set<string>>& readers, const string& reader_id) {
    cout << "Читатель " << reader_id << " имеет книги:";
    
    // Если у читателя есть книги на руках (строго Range-based)
    if (readers.count(reader_id) > 0) {
        bool first = true;
        for (const auto& book_id : readers.at(reader_id)) {
            if (!first) cout << ",";
            cout << " " << book_id;
            first = false;
        }
    }
    cout << "\n";
}
