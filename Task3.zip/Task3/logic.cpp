#include "logic.h"

using namespace std;

void createMetro(map<string, vector<string>>& lines, map<string, set<string>>& stations, 
                 const string& lineName, int count, const vector<string>& lineStops) {
    
    // Проверка 1: Линия с таким именем уже существует
    if (lines.count(lineName) > 0) {
        cout << "Ошибка: Линия метро с именем " << lineName << " уже создана\n";
        return;
    }

    // Проверка 2: Метро не может состоять из 1 станции (минимум 2)
    if (count < 2) {
        cout << "Ошибка: Линия метро не может быть создана с менее чем двумя станциями\n";
        return;
    }

    // Проверка 3: На линии не должно быть дубликатов станций
    set<string> uniqueStops;
    for (const auto& stop : lineStops) {
        uniqueStops.insert(stop);
    }
    if (uniqueStops.size() < lineStops.size()) {
        cout << "Ошибка: Линия метро не может быть создана с двумя одинаковыми станциями\n";
        return;
    }

    // Если все проверки пройдены, сохраняем линию
    lines[lineName] = lineStops;

    // И добавляем эту линию в список линий для каждой станции
    for (const auto& stop : lineStops) {
        stations[stop].insert(lineName);
    }

    cout << "Линия метро " << lineName << " создана\n";
}

void metrosInStop(const map<string, set<string>>& stations, const string& stopName) {
    // Проверяем, существует ли станция
    if (stations.count(stopName) == 0) {
        cout << "Ошибка: Станция " << stopName << " не найдена\n";
        return;
    }

    cout << "Линии метро на станции " << stopName << ": ";
    bool first = true;
    for (const auto& line : stations.at(stopName)) {
        if (!first) cout << ", ";
        cout << line;
        first = false;
    }
    cout << "\n";
}

void stopsInMetro(const map<string, vector<string>>& lines, const map<string, set<string>>& stations, const string& lineName) {
    // Проверяем, существует ли линия
    if (lines.count(lineName) == 0) {
        cout << "Ошибка: Линия метро " << lineName << " не найдена\n";
        return;
    }

    // 1. Сначала выводим заглавную строку со всеми станциями линии в одну строку (как на скриншоте)
    cout << "Станции линии метро " << lineName << ":";
    for (const auto& stop : lines.at(lineName)) {
        cout << " " << stop;
    }
    cout << "\n";

    // 2. Затем для КАЖДОЙ станции выводим список других проходящих линий на новых строках
    for (const auto& stop : lines.at(lineName)) {
        cout << "Станция " << stop << ":";
        
        bool first = true;
        for (const auto& passing_line : stations.at(stop)) {
            // Пропускаем саму текущую линию, выводим только пересекающиеся
            if (passing_line != lineName) {
                if (!first) cout << ",";
                cout << " " << passing_line;
                first = false;
            }
        }
        cout << "\n";
    }
}

void printMetros(const map<string, vector<string>>& lines) {
    // Если линий вообще нет
    if (lines.empty()) {
        cout << "Ошибка: Линии метро не найдены\n";
        return;
    }

    // Выводим все линии и их станции
    for (const auto& line_pair : lines) {
        cout << "Линия " << line_pair.first << ": ";
        bool first = true;
        for (const auto& stop : line_pair.second) {
            if (!first) cout << " - ";
            cout << stop;
            first = false;
        }
        cout << "\n";
    }
}
