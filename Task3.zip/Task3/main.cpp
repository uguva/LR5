#include "logic.h"
#include <algorithm>
#include <limits>

using namespace std;

// Функция для безопасной очистки потока ввода
void clearInput() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
}

// Преобразование строковой команды в enum
CmdType parseCommand(string cmd) {
    transform(cmd.begin(), cmd.end(), cmd.begin(), ::toupper);
    if (cmd == "CREATE_METRO") return CmdType::CREATE_METRO;
    if (cmd == "METROS_IN_STOP") return CmdType::METROS_IN_STOP;
    if (cmd == "STOPS_IN_METRO") return CmdType::STOPS_IN_METRO;
    if (cmd == "METROS") return CmdType::METROS;
    if (cmd == "EXIT") return CmdType::EXIT;
    return CmdType::UNKNOWN;
}

int main() {
    map<string, vector<string>> lines;
    map<string, set<string>> stations;
    string input_cmd;

    cout << "Система метрополитена запущена.\n";

    while (cin >> input_cmd) {
        CmdType cmd = parseCommand(input_cmd);

        if (cmd == CmdType::CREATE_METRO) {
            string lineName;
            int count;
            cin >> lineName;

            // Защита от ввода букв вместо количества станций
            if (!(cin >> count)) {
                cout << "Ошибка: Количество станций должно быть целым числом!\n";
                clearInput();
                continue;
            }

            // Считываем список станций
            vector<string> lineStops;
            for (int i = 0; i < count; ++i) {
                string stop;
                cin >> stop;
                lineStops.push_back(stop);
            }

            createMetro(lines, stations, lineName, count, lineStops);
        }
        else if (cmd == CmdType::METROS_IN_STOP) {
            string stopName;
            cin >> stopName;
            metrosInStop(stations, stopName);
        }
        else if (cmd == CmdType::STOPS_IN_METRO) {
            string lineName;
            cin >> lineName;
            stopsInMetro(lines, stations, lineName);
        }
        else if (cmd == CmdType::METROS) {
            printMetros(lines);
        }
        else if (cmd == CmdType::EXIT) {
            break;
        }
        else {
            cout << "Ошибка: Неизвестная команда '" << input_cmd << "'\n";
            clearInput();
        }
    }

    return 0;
}
