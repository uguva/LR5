#pragma once

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>

// Хранение команд в классе enum, согласно требованиям задания
enum class CmdType {
    CREATE_METRO,
    METROS_IN_STOP,
    STOPS_IN_METRO,
    METROS,
    EXIT,
    UNKNOWN
};

// Объявления функций логики метро
void createMetro(std::map<std::string, std::vector<std::string>>& lines, 
                 std::map<std::string, std::set<std::string>>& stations, 
                 const std::string& lineName, int count, 
                 const std::vector<std::string>& lineStops);

void metrosInStop(const std::map<std::string, std::set<std::string>>& stations, 
                  const std::string& stopName);

void stopsInMetro(const std::map<std::string, std::vector<std::string>>& lines, 
                  const std::map<std::string, std::set<std::string>>& stations, 
                  const std::string& lineName);

void printMetros(const std::map<std::string, std::vector<std::string>>& lines);
